import os
import yaml
def reverse_fun():
      with open("users.json","r") as f:
          data = f.read()
      
      d = yaml.load(data, Loader=yaml.SafeLoader)
      return d

if __name__ == '__main__':
    try:  
        print(reverse_fun())
    except:
        print("error")
